# UG MAP
This is a Java-based terminal program that demonstrates the use of algorithms to identify the optimum path in a graph.

- First, all of the vantage points on campus are modelled in a graph, along with their relative distances.

- In the program, the graph is represented by an adjancency list.

- The distances between the various locations were calculated in advance using Google Map API.


## Language
- Java
Group members:
Ewurabena Kuranchie-Asiedu-10956662
Bright Addy-109978336
Aamina Hairat Futa-10956060
Wilson Boakye-109746867
Attakorah David Yaw-10957668
Adjah-Tetteh Spencer-10939430
Attakorah-Amaniampong Liezah-10981607
Danyal Hamza-10944646
Twum-Antwi Vanecia-10990540
John Henry Tong-10946307

